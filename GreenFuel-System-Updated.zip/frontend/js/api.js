// frontend/js/api.js
// All calls to the PHP backend go through these functions.
// BASE_URL points to your backend folder.

const BASE_URL = '../backend/routes';

async function apiFetch(route, params = {}, options = {}) {
  const url = new URL(`${BASE_URL}/${route}`, window.location.href);
  Object.entries(params).forEach(([k, v]) => url.searchParams.set(k, v));

  const res = await fetch(url.toString(), {
    credentials: 'include',
    headers: { 'Content-Type': 'application/json' },
    ...options,
  });

  const json = await res.json();
  if (!json.success && res.status !== 200) {
    throw new Error(json.error || 'Request failed');
  }
  return Object.prototype.hasOwnProperty.call(json, 'data') ? json.data : json;
}

// Shorthand helpers
const API = {
  // AUTH
  login:   (username, password, branch_id = null)  => apiFetch('auth.php', { action: 'login' },        { method: 'POST', body: JSON.stringify({ username, password, branch_id }) }),
  logout:  ()                    => apiFetch('auth.php', { action: 'logout' },        { method: 'POST' }),
  me:      ()                    => apiFetch('auth.php', { action: 'me' }),

  // BRANCHES + FUELS
  branches: ()                   => apiFetch('branches.php', { action: 'list' }),
  fuels:    ()                   => apiFetch('branches.php', { action: 'fuels' }),
  fuelUpdatePrice: (id, price)    => apiFetch('branches.php', { action: 'update_price' }, { method: 'POST', body: JSON.stringify({ id, price }) }),
  fuelPriceRequests: (params = {})=> apiFetch('branches.php', { action: 'price_requests', ...params }),
  fuelRequestPrice: (data)        => apiFetch('branches.php', { action: 'request_price' }, { method: 'POST', body: JSON.stringify(data) }),
  fuelReviewPrice: (request_id, status, review_note = '') =>
    apiFetch('branches.php', { action: 'review_price' }, { method: 'POST', body: JSON.stringify({ request_id, status, review_note }) }),
  settings: ()                    => apiFetch('settings.php', { action: 'list' }),
  settingUpdate: (setting_key, setting_value) =>
    apiFetch('settings.php', { action: 'update' }, { method: 'POST', body: JSON.stringify({ setting_key, setting_value }) }),

  // USER ROLE ASSIGNMENTS
  users: ()                       => apiFetch('users.php', { action: 'list' }),
  userSave: (data)                => apiFetch('users.php', { action: 'save' }, { method: 'POST', body: JSON.stringify(data) }),

  // TRANSACTIONS
  txList:   (params = {})        => apiFetch('transactions.php', { action: 'list',   ...params }),
  txToday:  (branch_id)          => apiFetch('transactions.php', { action: 'today',  branch_id }),
  txRecent: (branch_id, limit=12)=> apiFetch('transactions.php', { action: 'recent', branch_id, limit }),
  txCreate: (data)               => apiFetch('transactions.php', { action: 'create' }, { method: 'POST', body: JSON.stringify(data) }),
  txVerify: (tx_id, status)      => apiFetch('transactions.php', { action: 'verify' }, { method: 'POST', body: JSON.stringify({ tx_id, status }) }),
  txVoid:   (tx_id, reason)      => apiFetch('transactions.php', { action: 'void' }, { method: 'POST', body: JSON.stringify({ tx_id, reason }) }),
  denominations: ()              => apiFetch('transactions.php', { action: 'denominations' }),

  // ANALYTICS
  summary:        ()             => apiFetch('analytics.php', { action: 'summary' }),
  daily:          (params = {})  => apiFetch('analytics.php', { action: 'daily',          ...params }),
  branchRanking:  ()             => apiFetch('analytics.php', { action: 'branch_ranking' }),
  branchComparison: (params = {})=> apiFetch('analytics.php', { action: 'branch_comparison', ...params }),
  fuelBreakdown:  (branch_id)    => apiFetch('analytics.php', { action: 'fuel_breakdown', branch_id }),
  forecast:       ()             => apiFetch('analytics.php', { action: 'forecast' }),
  insights:       ()             => apiFetch('analytics.php', { action: 'insights' }),

  // SHIFTS
  shiftsPending: (branch_id)     => apiFetch('shifts.php', { action: 'pending', branch_id }),
  shiftsHistory: (branch_id)     => apiFetch('shifts.php', { action: 'history', branch_id }),
  shiftCurrent: ()               => apiFetch('shifts.php', { action: 'current' }),
  shiftStart: ()                 => apiFetch('shifts.php', { action: 'start' }, { method: 'POST' }),
  shiftEnd: ()                   => apiFetch('shifts.php', { action: 'end' }, { method: 'POST' }),
  shiftVerify:   (shift_id, status, remarks='') =>
    apiFetch('shifts.php', { action: 'verify' }, { method: 'POST', body: JSON.stringify({ shift_id, status, remarks }) }),
  shiftOpen: (data)              => apiFetch('shifts.php', { action: 'open' }, { method: 'POST', body: JSON.stringify(data) }),

  // DAILY ENTRIES
  dailyEntries: (params = {})    => apiFetch('daily_entries.php', { action: 'list', ...params }),
  dailyCashSummary: (params = {})=> apiFetch('daily_entries.php', { action: 'cash_summary', ...params }),
  dailyEntrySave: (data)         => apiFetch('daily_entries.php', { action: 'save' }, { method: 'POST', body: JSON.stringify(data) }),

  // REPORTS
  weeklyReport:  (params = {})   => apiFetch('reports.php', { action: 'weekly', ...params }),
  submitReport:  (data)          => apiFetch('reports.php', { action: 'submit' }, { method: 'POST', body: JSON.stringify(data) }),
  reportList:    (params = {})   => apiFetch('reports.php', { action: 'list', ...params }),
};
