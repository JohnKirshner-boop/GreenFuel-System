<?php
// backend/routes/auth.php
// POST ?action=login   { username, password }
// POST ?action=logout
// GET  ?action=me

require_once __DIR__ . '/../config.php';
startSession();

$action = $_GET['action'] ?? '';

switch ($action) {

    case 'login':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonError('POST required', 405);
        $b        = getBody();
        $username = trim($b['username'] ?? '');
        $password = trim($b['password']  ?? '');
        $branchId = trim($b['branch_id'] ?? '');
        if (!$username || !$password) jsonError('Username and password required.');

        $db   = getDB();
        $stmt = $db->prepare(
            'SELECT u.*, b.name AS branch_name, b.location AS branch_location
             FROM users u
             LEFT JOIN branches b ON b.id = u.branch_id
             WHERE u.username = ? LIMIT 1'
        );
        $stmt->execute([$username]);
        $user = $stmt->fetch();

        // Accept both bcrypt hash and plain text (dev convenience)
        $ok = $user && (
            password_verify($password, $user['password']) ||
            $user['password'] === $password
        );

        if (!$ok) jsonError('Invalid username or password.', 401);

        if ($user['role'] !== 'owner') {
            if (!$branchId) jsonError('Branch selection is required.', 400);
            if (empty($user['branch_id'])) jsonError('No branch is assigned to this account. Ask the owner to assign one.', 403);
            if ($branchId !== $user['branch_id']) jsonError('This account is not assigned to the selected branch.', 403);
            $bStmt = $db->prepare('SELECT id, name, location FROM branches WHERE id = ? LIMIT 1');
            $bStmt->execute([$branchId]);
            $branch = $bStmt->fetch();
            if (!$branch) jsonError('Invalid branch selected.', 400);
            $user['branch_id'] = $branch['id'];
            $user['branch_name'] = $branch['name'];
            $user['branch_location'] = $branch['location'];
        } else {
            $user['branch_id'] = null;
            $user['branch_name'] = null;
            $user['branch_location'] = null;
        }

        $_SESSION['user'] = [
            'id'              => (int)$user['id'],
            'username'        => $user['username'],
            'name'            => $user['name'],
            'role'            => $user['role'],
            'branch_id'       => $user['branch_id'],
            'branch_name'     => $user['branch_name'] ?? null,
            'branch_location' => $user['branch_location'] ?? null,
        ];
        jsonSuccess($_SESSION['user'], 'Login successful.');

    case 'logout':
        session_destroy();
        jsonSuccess(null, 'Logged out.');

    case 'me':
        $u = currentUser();
        if (!$u) jsonError('Not authenticated.', 401);
        jsonSuccess($u);

    default:
        jsonError('Unknown action.', 404);
}
