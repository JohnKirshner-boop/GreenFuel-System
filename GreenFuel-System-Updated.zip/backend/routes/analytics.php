<?php
// backend/routes/analytics.php
// GET ?action=summary          — network totals
// GET ?action=daily  [&branch_id=] [&days=7]
// GET ?action=branch_ranking
// GET ?action=fuel_breakdown   [&branch_id=]
// GET ?action=forecast         [&branch_id=]

require_once __DIR__ . '/../config.php';
requireRole('owner', 'manager');
$action = $_GET['action'] ?? 'summary';
$db     = getDB();

function analyticsTableExists(PDO $db, string $table): bool {
    $stmt = $db->prepare(
        'SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES
         WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?'
    );
    $stmt->execute([DB_NAME, $table]);
    return (int)$stmt->fetchColumn() > 0;
}

function analyticsMonthWeeks(string $month): array {
    if (!preg_match('/^\d{4}-\d{2}$/', $month)) {
        jsonError('Invalid month. Use YYYY-MM.');
    }
    $start = new DateTimeImmutable($month.'-01');
    $lastDay = (int)$start->format('t');
    $weeks = [];
    for ($day = 1, $week = 1; $day <= $lastDay; $day += 7, $week++) {
        $from = $start->setDate((int)$start->format('Y'), (int)$start->format('m'), $day);
        $toDay = min($day + 6, $lastDay);
        $to = $start->setDate((int)$start->format('Y'), (int)$start->format('m'), $toDay);
        $weeks[] = [
            'number' => $week,
            'label'  => 'Week '.$week,
            'start'  => $from->format('Y-m-d'),
            'end'    => $to->format('Y-m-d'),
        ];
    }
    return $weeks;
}

function analyticsDailyEntryAgg(PDO $db, string $start, string $end): array {
    if (!analyticsTableExists($db, 'daily_entries')) return [];
    $stmt = $db->prepare(
        "SELECT branch_id, total_cash_expected, payload_json
         FROM daily_entries
         WHERE entry_date BETWEEN ? AND ?
           AND status IN ('submitted','reviewed')"
    );
    $stmt->execute([$start, $end]);
    $agg = [];
    foreach ($stmt->fetchAll() as $entry) {
        $bid = $entry['branch_id'];
        if (!isset($agg[$bid])) {
            $agg[$bid] = ['tx_count' => 0, 'revenue' => 0.0, 'liters' => 0.0];
        }
        $agg[$bid]['tx_count']++;
        $agg[$bid]['revenue'] += (float)$entry['total_cash_expected'];
        $payload = json_decode($entry['payload_json'] ?? '{}', true);
        if (is_array($payload)) {
            for ($pump = 1; $pump <= 4; $pump++) {
                $agg[$bid]['liters'] += (float)($payload["digital__pump{$pump}__consumed"] ?? 0);
            }
        }
    }
    return $agg;
}

function analyticsTransactionAgg(PDO $db, string $start, string $end): array {
    $stmt = $db->prepare(
        "SELECT branch_id,
                COUNT(*) AS tx_count,
                COALESCE(SUM(total_amount),0) AS revenue,
                COALESCE(SUM(liters),0) AS liters
         FROM transactions
         WHERE status != 'void'
           AND DATE(timestamp) BETWEEN ? AND ?
         GROUP BY branch_id"
    );
    $stmt->execute([$start, $end]);
    $agg = [];
    foreach ($stmt->fetchAll() as $row) {
        $agg[$row['branch_id']] = [
            'tx_count' => (int)$row['tx_count'],
            'revenue' => (float)$row['revenue'],
            'liters' => (float)$row['liters'],
        ];
    }
    return $agg;
}

function analyticsBranchRowsForRange(PDO $db, array $branches, string $start, string $end): array {
    $daily = analyticsDailyEntryAgg($db, $start, $end);
    $tx = analyticsTransactionAgg($db, $start, $end);
    $rows = [];
    foreach ($branches as $branch) {
        $bid = $branch['id'];
        $source = 'none';
        $metrics = ['tx_count' => 0, 'revenue' => 0.0, 'liters' => 0.0];
        if (isset($daily[$bid]) && ($daily[$bid]['tx_count'] > 0 || $daily[$bid]['revenue'] > 0)) {
            $metrics = $daily[$bid];
            $source = 'daily_entries';
        } elseif (isset($tx[$bid])) {
            $metrics = $tx[$bid];
            $source = 'transactions';
        }
        $rows[] = [
            'id' => $bid,
            'name' => $branch['name'],
            'location' => $branch['location'],
            'tx_count' => (int)$metrics['tx_count'],
            'revenue' => round((float)$metrics['revenue'], 2),
            'liters' => round((float)$metrics['liters'], 2),
            'avg_tx' => $metrics['tx_count'] > 0 ? round((float)$metrics['revenue'] / (int)$metrics['tx_count'], 2) : 0,
            'source' => $source,
        ];
    }
    usort($rows, fn($a, $b) => $b['revenue'] <=> $a['revenue']);
    return $rows;
}

switch ($action) {

    // ---- OVERALL NETWORK SUMMARY ----
    case 'summary': {
        $row = $db->query(
            'SELECT COUNT(*) AS tx_count,
                    SUM(total_amount) AS total_revenue,
                    SUM(tax_amount) AS total_tax,
                    SUM(liters) AS total_liters,
                    AVG(total_amount) AS avg_tx
             FROM transactions
             WHERE status != \'void\''
        )->fetch();
        $today = $db->query(
            'SELECT COUNT(*) AS tx_count,
                    COALESCE(SUM(total_amount),0) AS revenue,
                    COALESCE(SUM(tax_amount),0) AS tax,
                    COALESCE(SUM(liters),0) AS liters
             FROM transactions WHERE status != \'void\' AND DATE(timestamp)=CURDATE()'
        )->fetch();
        jsonSuccess(['all_time' => $row, 'today' => $today]);
    }

    // ---- DAILY REVENUE PER BRANCH ----
    case 'daily': {
        $days = min((int)($_GET['days'] ?? 7), 90);
        $bid  = $_GET['branch_id'] ?? null;
        $extra = $bid ? ' AND t.branch_id = ?' : '';
        $params = [$days];
        if ($bid) $params[] = $bid;
        $stmt = $db->prepare(
            'SELECT DATE(t.timestamp) AS day,
                    t.branch_id,
                    b.name AS branch_name,
                    COUNT(*) AS tx_count,
                    SUM(t.total_amount) AS revenue,
                    SUM(t.tax_amount) AS tax,
                    SUM(t.liters) AS liters
             FROM transactions t
             LEFT JOIN branches b ON b.id = t.branch_id
             WHERE t.status != \'void\' AND t.timestamp >= DATE_SUB(CURDATE(), INTERVAL ? DAY)'.$extra.'
             GROUP BY DATE(t.timestamp), t.branch_id
             ORDER BY day ASC, t.branch_id'
        );
        $stmt->execute($params);
        jsonSuccess($stmt->fetchAll());
    }

    // ---- BRANCH RANKING ----
    case 'branch_ranking': {
        $stmt = $db->query(
            'SELECT b.id, b.name, b.location,
                    COUNT(t.id) AS tx_count,
                    COALESCE(SUM(t.total_amount),0) AS revenue,
                    COALESCE(SUM(t.liters),0) AS liters,
                    COALESCE(AVG(t.total_amount),0) AS avg_tx
             FROM branches b
             LEFT JOIN transactions t ON t.branch_id = b.id AND t.status != \'void\'
             GROUP BY b.id
             ORDER BY revenue DESC'
        );
        jsonSuccess($stmt->fetchAll());
    }

    // ---- BRANCH COMPARISON BY WEEKS OF THE SELECTED MONTH ----
    case 'branch_comparison': {
        requireRole('owner');
        $month = $_GET['month'] ?? date('Y-m');
        $weeks = analyticsMonthWeeks($month);
        $selectedWeek = max(1, (int)($_GET['week'] ?? 0));
        if ($selectedWeek < 1 || $selectedWeek > count($weeks)) {
            $today = date('Y-m-d');
            $selectedWeek = 1;
            if ($month === date('Y-m')) {
                foreach ($weeks as $week) {
                    if ($today >= $week['start'] && $today <= $week['end']) {
                        $selectedWeek = (int)$week['number'];
                        break;
                    }
                }
            }
        }

        $branches = $db->query('SELECT id, name, location FROM branches ORDER BY name')->fetchAll();
        $selectedRange = $weeks[$selectedWeek - 1];
        $ranking = analyticsBranchRowsForRange($db, $branches, $selectedRange['start'], $selectedRange['end']);
        $previousRows = $selectedWeek > 1
            ? analyticsBranchRowsForRange($db, $branches, $weeks[$selectedWeek - 2]['start'], $weeks[$selectedWeek - 2]['end'])
            : [];
        $previousByBranch = [];
        foreach ($previousRows as $row) $previousByBranch[$row['id']] = (float)$row['revenue'];

        foreach ($ranking as &$row) {
            $previous = $previousByBranch[$row['id']] ?? 0.0;
            $current = (float)$row['revenue'];
            $row['previous_revenue'] = round($previous, 2);
            $row['growth_pct'] = $previous > 0 ? round((($current - $previous) / $previous) * 100, 1) : ($current > 0 ? 100.0 : 0.0);
        }
        unset($row);
        usort($ranking, fn($a, $b) => $b['revenue'] <=> $a['revenue']);

        $trendByBranch = [];
        foreach ($branches as $branch) {
            $trendByBranch[$branch['id']] = [
                'branch_id' => $branch['id'],
                'branch_name' => $branch['name'],
                'data' => [],
            ];
        }
        foreach ($weeks as $week) {
            $weekRows = analyticsBranchRowsForRange($db, $branches, $week['start'], $week['end']);
            foreach ($weekRows as $row) {
                $trendByBranch[$row['id']]['data'][] = [
                    'week_number' => $week['number'],
                    'label' => $week['label'],
                    'start' => $week['start'],
                    'end' => $week['end'],
                    'revenue' => $row['revenue'],
                    'liters' => $row['liters'],
                    'tx_count' => $row['tx_count'],
                    'source' => $row['source'],
                ];
            }
        }

        jsonSuccess([
            'month' => $month,
            'selected_week' => $selectedWeek,
            'selected_range' => $selectedRange,
            'weeks' => $weeks,
            'ranking' => $ranking,
            'trends' => array_values($trendByBranch),
        ]);
    }

    // ---- FUEL BREAKDOWN ----
    case 'fuel_breakdown': {
        $bid    = $_GET['branch_id'] ?? null;
        $extra  = $bid ? ' AND t.branch_id = ?' : '';
        $params = $bid ? [$bid] : [];
        $stmt   = $db->prepare(
            'SELECT f.id, f.name, f.color,
                    COUNT(t.id) AS tx_count,
                    COALESCE(SUM(t.liters),0) AS liters,
                    COALESCE(SUM(t.total_amount),0) AS revenue
             FROM fuel_types f
             LEFT JOIN transactions t ON t.fuel_type = f.id AND t.status != \'void\''.$extra.'
             GROUP BY f.id
             ORDER BY revenue DESC'
        );
        $stmt->execute($params);
        jsonSuccess($stmt->fetchAll());
    }

    // ---- FORECAST (3-day moving average) ----
    case 'forecast': {
        // Get last 7 days of revenue per branch
        $stmt = $db->query(
            'SELECT b.id AS branch_id, b.name AS branch_name,
                    DATE(t.timestamp) AS day,
                    COALESCE(SUM(t.total_amount),0) AS revenue,
                    COALESCE(SUM(t.liters),0) AS liters
             FROM branches b
             LEFT JOIN transactions t
               ON t.branch_id = b.id
               AND t.timestamp >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
               AND t.status != \'void\'
             GROUP BY b.id, DATE(t.timestamp)
             ORDER BY b.id, day'
        );
        $rows = $stmt->fetchAll();

        // Also get branch-level averages for comparison
        $avgStmt = $db->query(
            'SELECT branch_id,
                    AVG(daily_rev) AS avg_daily_revenue
             FROM (
               SELECT branch_id, DATE(timestamp) AS d, SUM(total_amount) AS daily_rev
               FROM transactions
               WHERE status != \'void\'
               GROUP BY branch_id, DATE(timestamp)
             ) AS daily
             GROUP BY branch_id'
        );
        $avgs = [];
        foreach ($avgStmt->fetchAll() as $a) {
            $avgs[$a['branch_id']] = (float)$a['avg_daily_revenue'];
        }

        // Group by branch
        $byBranch = [];
        foreach ($rows as $r) {
            $byBranch[$r['branch_id']]['name'] = $r['branch_name'];
            $byBranch[$r['branch_id']]['days'][] = [
                'day'     => $r['day'],
                'revenue' => (float)$r['revenue'],
                'liters'  => (float)$r['liters'],
            ];
        }

        $result = [];
        foreach ($byBranch as $bid => $data) {
            $days    = $data['days'] ?? [];
            $last3   = array_slice($days, -3);
            $ma      = count($last3) ? array_sum(array_column($last3, 'revenue')) / count($last3) : 0;
            $avg     = $avgs[$bid] ?? 1;
            $suggest = $ma > $avg * 1.1 ? 'increase stock'
                     : ($ma < $avg * 0.85 ? 'low sales alert' : 'normal demand');
            $result[] = [
                'branch_id'   => $bid,
                'branch_name' => $data['name'],
                'forecast_ma' => round($ma, 2),
                'avg_daily'   => round($avg, 2),
                'suggestion'  => $suggest,
                'daily_data'  => $days,
            ];
        }
        jsonSuccess($result);
    }

    // ---- INSIGHTS (decision support) ----
    case 'insights': {
        $ranking = $db->query(
            'SELECT b.name, COALESCE(SUM(t.total_amount),0) AS revenue
             FROM branches b
             LEFT JOIN transactions t ON t.branch_id = b.id AND t.status != \'void\'
             GROUP BY b.id ORDER BY revenue DESC'
        )->fetchAll();

        $trend = $db->query(
            'SELECT DATE(timestamp) AS day, SUM(liters) AS liters
             FROM transactions
             WHERE status != \'void\' AND timestamp >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
             GROUP BY DATE(timestamp) ORDER BY day'
        )->fetchAll();

        $liters = array_column($trend, 'liters');
        $half   = intdiv(count($liters), 2);
        $early  = $half > 0 ? array_sum(array_slice($liters, 0, $half)) / $half : 0;
        $recent = $half > 0 ? array_sum(array_slice($liters, -$half)) / $half   : 0;
        $trendUp = $recent > $early;

        $top     = $ranking[0] ?? null;
        $bottom  = end($ranking) ?: null;

        $insights = [];
        if ($top)    $insights[] = ['type'=>'success','label'=>'Top Performer','text'=>$top['name'].' leads with ₱'.number_format($top['revenue'],2).' in total revenue.'];
        if ($bottom) $insights[] = ['type'=>'warning','label'=>'Action Needed','text'=>$bottom['name'].' has the lowest revenue at ₱'.number_format($bottom['revenue'],2).'. Consider a promotion.'];
        $insights[] = ['type'=>$trendUp?'success':'danger','label'=>'Sales Trend','text'=>'Network sales volume is '.($trendUp?'increasing — demand is growing.':'declining — consider promotions.')];
        jsonSuccess($insights);
    }

    default:
        jsonError('Unknown action.', 404);
}
