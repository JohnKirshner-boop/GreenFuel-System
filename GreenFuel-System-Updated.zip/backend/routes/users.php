<?php
// backend/routes/users.php
// Owner-only user and role assignment management.

require_once __DIR__ . '/../config.php';
$user = requireRole('owner');
$action = $_GET['action'] ?? 'list';
$db = getDB();

function roleBranch(PDO $db, ?string $branchId): ?array {
    if (!$branchId) return null;
    $stmt = $db->prepare('SELECT id, name, location FROM branches WHERE id=? LIMIT 1');
    $stmt->execute([$branchId]);
    $branch = $stmt->fetch();
    return $branch ?: null;
}

switch ($action) {
    case 'list': {
        $stmt = $db->query(
            "SELECT u.id, u.username, u.name, u.role, u.branch_id, u.created_at,
                    b.name AS branch_name, b.location AS branch_location
             FROM users u
             LEFT JOIN branches b ON b.id = u.branch_id
             ORDER BY FIELD(u.role, 'owner','manager','cashier'), u.name"
        );
        jsonSuccess($stmt->fetchAll());
    }

    case 'save': {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonError('POST required', 405);
        $b = getBody();
        $id = (int)($b['id'] ?? 0);
        $name = trim($b['name'] ?? '');
        $username = trim($b['username'] ?? '');
        $password = (string)($b['password'] ?? '');
        $role = trim($b['role'] ?? '');
        $branchId = trim($b['branch_id'] ?? '');

        if (!$name) jsonError('Full name is required.');
        if (!$username) jsonError('Username is required.');
        if (!in_array($role, ['owner', 'manager', 'cashier'], true)) jsonError('Choose a valid role.');

        if ($role === 'owner') {
            $branchId = null;
        } else {
            $branch = roleBranch($db, $branchId);
            if (!$branch) jsonError('Managers and cashiers must be assigned to a valid branch.');
        }

        if ($id > 0) {
            $check = $db->prepare('SELECT id, role FROM users WHERE id=? LIMIT 1');
            $check->execute([$id]);
            $existing = $check->fetch();
            if (!$existing) jsonError('User not found.', 404);
            if ($existing['role'] === 'owner' && $role !== 'owner') {
                $owners = $db->prepare("SELECT COUNT(*) FROM users WHERE role='owner' AND id<>?");
                $owners->execute([$id]);
                if ((int)$owners->fetchColumn() < 1) {
                    jsonError('At least one owner account must remain.');
                }
            }

            $dupe = $db->prepare('SELECT id FROM users WHERE username=? AND id<>? LIMIT 1');
            $dupe->execute([$username, $id]);
            if ($dupe->fetch()) jsonError('Username is already used by another account.');

            if ($password !== '') {
                $stmt = $db->prepare(
                    'UPDATE users SET username=?, password=?, name=?, role=?, branch_id=? WHERE id=?'
                );
                $stmt->execute([$username, password_hash($password, PASSWORD_DEFAULT), $name, $role, $branchId, $id]);
            } else {
                $stmt = $db->prepare(
                    'UPDATE users SET username=?, name=?, role=?, branch_id=? WHERE id=?'
                );
                $stmt->execute([$username, $name, $role, $branchId, $id]);
            }
            jsonSuccess(['id' => $id], 'User assignment updated.');
        }

        if ($password === '') jsonError('Password is required for a new user.');
        $stmt = $db->prepare(
            'INSERT INTO users (username, password, name, role, branch_id)
             VALUES (?,?,?,?,?)'
        );
        try {
            $stmt->execute([$username, password_hash($password, PASSWORD_DEFAULT), $name, $role, $branchId]);
        } catch (PDOException $e) {
            if ($e->getCode() === '23000') jsonError('Username is already used by another account.');
            throw $e;
        }
        jsonSuccess(['id' => $db->lastInsertId()], 'User assignment created.');
    }

    default:
        jsonError('Unknown action.', 404);
}
